import{c as e,j as r,r as s,m as d,M as o}from"./base-9CyWlTB4.js";e(document.getElementById("root")).render(r.jsx(s.StrictMode,{children:r.jsx(d.Provider,{children:r.jsx(o,{})})}));
